export type Role = {
  title: string;
  slug: string;
  description: string;
  acceptTicket?: boolean;
  titleInTicket?: string;
};
