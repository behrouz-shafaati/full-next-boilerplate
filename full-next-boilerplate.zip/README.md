installation:
step: set .env variable
step : set seed data in @/lib/seed-data.js [You must set super admin user here]
step : if your db is raw: run pnpm seed
step :

version guide: 0.1.1 => main.sub.db
