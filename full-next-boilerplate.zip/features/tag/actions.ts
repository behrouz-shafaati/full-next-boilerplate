'use server'

import { z } from 'zod'
import tagCtrl from './controller'
import { redirect } from 'next/navigation'
import { Session, State } from '@/types'
import { Tag, TagTranslationSchema } from './interface'
import { getSession } from '@/lib/auth'
import revalidatePathCtrl from '@/lib/revalidatePathCtrl'
import { revalidatePath } from 'next/cache'

const FormSchema = z.object({
  title: z.string({}).min(1, { message: 'لطفا عنوان را وارد کنید.' }),
  slug: z.string({}).nullable(),
  lang: z.string({}).nullable(),
  description: z.string({}),
  status: z.string({}),
  image: z.string({}).nullable(),
})

async function sanitizePostData(validatedFields: any, id?: string | undefined) {
  let prevState = { translations: [] }
  if (id) {
    prevState = await tagCtrl.findById({ id })
    console.log('#prevState 098776 :', prevState)
  }
  const session = (await getSession()) as Session
  const payload = validatedFields.data
  const user = session.user.id
  const translations = [
    {
      lang: payload.lang,
      title: payload.title,
      description: payload.description,
    },
    ...prevState.translations.filter(
      (t: TagTranslationSchema) => t.lang != payload.lang
    ),
  ]
  const params = {
    ...payload,
    translations,
    user,
  }

  return params
}

/**
 * Creates a tag with the given form data.
 *
 * @param prevState - The previous state.
 * @param formData - The form data.
 * @returns An object with errors and a message if there are any, or redirects to the tag dashboard.
 */
export async function createTag(prevState: State, formData: FormData) {
  const rawValues = Object.fromEntries(formData)
  const values = {
    ...rawValues,
    translation: {
      lang: rawValues?.lang,
      title: rawValues?.title,
      description: rawValues?.description,
    },
  }
  console.log('#234 values:', values)
  // Validate form fields
  const validatedFields = FormSchema.safeParse(
    Object.fromEntries(formData.entries())
  )
  // If form validation fails, return errors early. Otherwise, continue.
  if (!validatedFields.success) {
    return {
      errors: validatedFields.error.flatten().fieldErrors,
      message: 'لطفا فیلدهای لازم را پر کنید.',
      values,
    }
  }

  try {
    const params = await sanitizePostData(validatedFields)
    // Create the tag
    await tagCtrl.create({ params })
    // Revalidate the path
    const pathes = await revalidatePathCtrl.getAllPathesNeedRevalidate({
      feature: 'tag',
      slug: [`/dashboard/tags`],
    })

    for (const slug of pathes) {
      // این تابع باید یا در همین فایل سرور اکشن یا از طریق api فراخوانی شود. پس محلش نباید تغییر کند.
      revalidatePath(slug)
    }
  } catch (error) {
    console.log('#2345 error:', error)
    // Handle database error
    if (error instanceof z.ZodError) {
      return {
        errors: error.flatten().fieldErrors,
      }
    }
    return {
      message: 'خطای پایگاه داده: ایجاد برچسب ناموفق بود.',
      values,
    }
  }
  redirect('/dashboard/tags')
}

export async function updateTag(
  id: string,
  prevState: State,
  formData: FormData
) {
  const values = Object.fromEntries(formData.entries())
  const validatedFields = FormSchema.safeParse(
    Object.fromEntries(formData.entries())
  )

  // If form validation fails, return errors early. Otherwise, continue.
  if (!validatedFields.success) {
    return {
      errors: validatedFields.error.flatten().fieldErrors,
      message: 'لطفا فیلدهای لازم را پر کنید.',
      values,
    }
  }
  try {
    const params = await sanitizePostData(validatedFields, id)
    await tagCtrl.findOneAndUpdate({
      filters: id,
      params: validatedFields.data,
    })
    const pathes = await revalidatePathCtrl.getAllPathesNeedRevalidate({
      feature: 'tag',
      slug: [`/dashboard/tags`],
    })

    for (const slug of pathes) {
      // این تابع باید یا در همین فایل سرور اکشن یا از طریق api فراخوانی شود. پس محلش نباید تغییر کند.
      revalidatePath(slug)
    }
  } catch (error) {
    return { message: 'خطای پایگاه داده: بروزرسانی برچسب ناموفق بود.', values }
  }
  redirect('/dashboard/tags')
}

export async function deleteTag(id: string) {
  try {
    await tagCtrl.delete({ filters: [id] })
    const pathes = await revalidatePathCtrl.getAllPathesNeedRevalidate({
      feature: 'tag',
      slug: [`/dashboard/tags`],
    })

    for (const slug of pathes) {
      // این تابع باید یا در همین فایل سرور اکشن یا از طریق api فراخوانی شود. پس محلش نباید تغییر کند.
      revalidatePath(slug)
    }
  } catch (error) {
    return { message: 'خطای پایگاه داده: حذف برچسب ناموفق بود' }
  }
  await tagCtrl.delete({ filters: [id] })
}

export async function getAllTags() {
  return tagCtrl.findAll({})
}

export async function searchTags(query: string, locale: string = 'fa') {
  const results = await tagCtrl.find({ filters: { query } })

  return results.data.map((tag: Tag) => {
    const translation: any =
      tag?.translations?.find((t: any) => t.lang === locale) ||
      tag?.translations[0] ||
      {}
    return {
      label: translation?.title,
      value: String(tag.id),
    }
  })
}
