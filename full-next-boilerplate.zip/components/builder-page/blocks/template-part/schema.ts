export const TemplateBlockSchema = {
  title: '',
  type: 'object',
  properties: {},
  required: [],
}
