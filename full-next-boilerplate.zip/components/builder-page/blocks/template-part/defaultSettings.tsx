export const templateBlockDefaults = {
  content: [],
  settings: {},
}
