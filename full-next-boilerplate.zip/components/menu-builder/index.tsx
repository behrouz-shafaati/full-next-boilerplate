import MenuBuilder from './components/menu-builder';

export default MenuBuilder;
