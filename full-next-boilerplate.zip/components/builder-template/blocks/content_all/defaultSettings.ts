export const contentBlockDefaults = {
  content: {},
  settings: {},
}
