export const contentBlockSchema = {
  title: '',
  type: 'object',
  properties: {},
}
