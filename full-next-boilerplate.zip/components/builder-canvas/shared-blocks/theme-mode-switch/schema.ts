export const themeModdeSwitchSchema = {
  title: '',
  type: 'object',
  properties: {},
}
