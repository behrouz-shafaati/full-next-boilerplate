export const themeModeSwitchDefaults = {
  content: {},
  settings: {},
}
