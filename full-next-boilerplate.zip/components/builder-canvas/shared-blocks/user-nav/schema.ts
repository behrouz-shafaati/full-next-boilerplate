export const userNavSchema = {
  title: '',
  type: 'object',
  properties: {},
}
