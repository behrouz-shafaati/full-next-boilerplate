export const userNavDefaults = {
  content: {},
  settings: {},
}
