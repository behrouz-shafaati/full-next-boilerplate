const blockSchema = {
  // title: 'تنظیمات ردیف',
  type: 'object',
  properties: {
    // rowColumns: {
    //   type: 'string',
    //   title: 'چینش ستونی',
    //   enum: ['3-3-3-3', '4-4-4', '2-8-2', '3-6-3', '12'],
    //   default: '4-4-4',
    // },
  },
}

export default blockSchema
