export const rowBlockDefaults = {
  styles: {},
}
