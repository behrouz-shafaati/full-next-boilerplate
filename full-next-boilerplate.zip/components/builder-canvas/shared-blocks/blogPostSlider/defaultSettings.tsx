export const blogPostSliderBlockDefaults = {
  content: [],
  settings: {},
}
