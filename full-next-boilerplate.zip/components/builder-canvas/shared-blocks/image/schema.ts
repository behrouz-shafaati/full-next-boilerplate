export const ImageBlockSchema = {
  title: 'تنظیمات تصویر ',
  type: 'object',
  properties: {},
}
