export const imageBlockDefaults = {
  content: {
    title: '',
    alt: '',
    description: '',
    src: null,
    href: null,
  },
  settings: {},
}
