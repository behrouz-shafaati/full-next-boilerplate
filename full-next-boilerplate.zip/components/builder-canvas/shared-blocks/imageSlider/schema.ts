export const ImageSliderBlockSchema = {
  title: 'تنظیمات اسلایدر تصویر ',
  type: 'object',
  properties: {
    delay: { type: 'number', title: 'مکث اسلاید', default: 3 },
  },
}
