export const imageSliderBlockDefaults = {
  content: [],
  settings: {},
}
