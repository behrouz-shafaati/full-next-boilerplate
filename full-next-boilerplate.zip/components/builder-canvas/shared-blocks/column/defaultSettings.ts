export const columnBlockDefaults = {
  styles: {},
}
