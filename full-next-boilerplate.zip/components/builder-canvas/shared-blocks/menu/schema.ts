export const MenuBlockSchema = {
  title: '',
  type: 'object',
  properties: {
    // sticky: { type: 'boolean', title: '', default: true },
  },
}
