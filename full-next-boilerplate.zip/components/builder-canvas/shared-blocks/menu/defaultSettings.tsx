export const menuBlockDefaults = {
  content: [],
  settings: {},
}
