export const textBlockDefaults = {
  content: { text: 'متن اولیه' },
  settings: {
    fontSize: '14px',
    fontWeight: 'normal',
    textAlign: 'right',
    color: '#000000',
  },
}
