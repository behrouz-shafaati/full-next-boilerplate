export const textBlockDefaults = {
  content: { text: 'متن اولیه' },
  settings: {
    fontSize: 14,
    fontWeight: 'normal',
    textAlign: 'right',
    color: '#000000',
  },
}
