export function getEmbedUrl(url: string): string | null {
  // YouTube
  const youtubeRegex = /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/
  const aparatRegex = /aparat\.com\/v\/([a-zA-Z0-9_-]+)/

  if (youtubeRegex.test(url)) {
    const id = url.match(youtubeRegex)?.[1]
    return `https://www.youtube.com/embed/${id}`
  }

  if (aparatRegex.test(url)) {
    const id = url.match(aparatRegex)?.[1]
    return `https://www.aparat.com/video/video/embed/videohash/${id}/vt/frame`
  }

  return url
}
